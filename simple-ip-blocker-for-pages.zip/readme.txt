=== Simple IP Blocker for Pages ===
Contributors: philippe Mathis
Donate link: https://buymeacoffee.com/pmathis
Tags: ip, block, security, ban, spam
Requires at least: 6.0
Tested up to: 6.8
Stable tag: 1.8.6.7
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Block specific IPv4 addresses or CIDR ranges from accessing selected WordPress pages. Lightweight, simple, and user-friendly.

== Description ==

Simple IP Blocker for Pages allows administrators to restrict access to selected pages based on visitor IP addresses. It is designed to be lightweight and easy to use, without complex configuration[cite: 106, 107].

**Features:**
- Block exact IPv4 addresses or CIDR ranges (e.g., 192.168.1.0/24)[cite: 108].
- Select one or more pages to protect[cite: 108].
- Customize the block message with safe HTML[cite: 109].
- Optionally redirect blocked visitors to another URL[cite: 109].
- Simple admin interface with clear feedback messages[cite: 110].

== Installation ==

1. **Install and Activate:** Install the plugin via the WordPress plugins screen (Search for "Simple IP Blocker") or by uploading the ZIP file. Activate it immediately[cite: 110, 111].
2. **Access Settings:** Go to **IP Blocker** in your WordPress admin menu[cite: 111].
3. **Select Pages to Protect:** In the **Pages to protect** section, select the pages that should restrict access (Use Ctrl/Cmd for multi-selection)[cite: 112].
4. **Customize Block Action:** Define a custom **Block message** and/or an **optional Redirect URL** (e.g., https://example.com/login)[cite: 113].
5. **Add IPs/Ranges:** In the "Add new blocked IPs" section, enter IP addresses or CIDR ranges, one per line (e.g., `203.0.113.45` or `192.168.1.0/24`)[cite: 114].
6. **Save:** Click **Save settings** to apply the configuration[cite: 115].
7. **Manage:** Use the **Manage IPs** sub-menu to view and remove existing blocked entries[cite: 115].

== Frequently Asked Questions ==

= Can I block IP ranges? =
Yes. You can block exact IPv4 addresses or use CIDR notation (e.g., `192.168.0.0/24`) to block a range of IPs[cite: 116, 117].

= What happens when a blocked IP visits a protected page? =
They will either see your custom block message or be redirected to the URL you specify in the settings[cite: 118, 119].

= Is HTML allowed in the block message? =
Yes, safe HTML tags such as `<strong>`, `<em>`, and `<a>` are allowed. All content is filtered through `wp_kses_post` for security[cite: 120, 121].

== Screenshots ==

1. Settings page with page selection and block message.
2. Add new blocked IPs form.
3. Manage blocked IPs list.

== Changelog ==

= 1.8.6.5 =
* Update: Updated "Tested up to" tag to 6.8.
* Fix: Fixed "Too many tags" warning in readme.txt.
* Feature: Added "Settings" link directly in the plugins list.

= 1.8.6.4 =
* Security Update: Implemented strict sanitization and nonce verification to meet WordPress.org standards.
* Fix: Improved CIDR range handling logic.

= 1.8.6 =
* Initial stable release with IP blocking and admin interface.

== Upgrade Notice ==

= 1.8.6.5 =
This update fixes repository validation warnings and updates compatibility tags for WordPress 6.8.